export const version = 'v2.2.0-066';
export const changeLog = 'https://t.me/jiaolongwang/109';
