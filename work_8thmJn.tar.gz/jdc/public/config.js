window.ql = {
    node: [
        {
            name: "节点1",
            url: "http://127.0.0.1:5701/"
        },
        {
            name: "节点2",
            url: "http://127.0.0.1:5702/"
        }
    ]
};
